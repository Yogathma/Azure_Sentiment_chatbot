import os
from dotenv import load_dotenv
import streamlit as st
import requests

# Load Azure credentials
load_dotenv()
AZURE_KEY = os.getenv("AZURE_KEY")
AZURE_ENDPOINT = os.getenv("AZURE_ENDPOINT")
SENTIMENT_URL = AZURE_ENDPOINT + "/text/analytics/v3.1/sentiment"

# Streamlit app
st.set_page_config(page_title="Azure Chatbot")
st.title("🤖 Azure Sentiment Chatbot")

user_input = st.text_input("You:", "")

if st.button("Analyze") and user_input:
    headers = {
        "Ocp-Apim-Subscription-Key": AZURE_KEY,
        "Content-Type": "application/json"
    }
    body = {
        "documents": [
            {
                "id": "1",
                "language": "en",
                "text": user_input
            }
        ]
    }

    response = requests.post(SENTIMENT_URL, headers=headers, json=body)
    result = response.json()

    if "documents" in result:
        sentiment = result["documents"][0]["sentiment"]
        score = result["documents"][0]["confidenceScores"][sentiment]
        st.success(f"🧠 Sentiment: **{sentiment.upper()}** (Confidence: {score:.2f})")
    else:
        st.error("Error: " + str(result))
